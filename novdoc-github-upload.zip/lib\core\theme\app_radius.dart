abstract final class AppRadius {
  static const theme = 16.0;
  static const pill = 999.0;
  static const iconButton = 22.0;
}
