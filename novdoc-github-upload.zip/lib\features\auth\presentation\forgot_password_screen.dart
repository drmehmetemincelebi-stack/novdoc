import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_radius.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/novdoc_button.dart';
import '../../../core/widgets/novdoc_icon_button.dart';

class ForgotPasswordScreen extends StatelessWidget {
  const ForgotPasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(
                  AppSpacing.screenHorizontal,
                  24,
                  AppSpacing.screenHorizontal,
                  24,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        NovdocIconButton(
                          icon: LucideIcons.arrow_left,
                          onPressed: () => context.pop(),
                          semanticLabel: 'Geri dön',
                        ),
                        Text(
                          'NOVDOC',
                          style: AppTypography.heading(
                            fontSize: 19,
                            fontWeight: FontWeight.w800,
                            color: AppColors.primary,
                          ),
                        ),
                        const SizedBox(width: 44),
                      ],
                    ),
                    const SizedBox(height: 48),
                    Container(
                      width: 64,
                      height: 64,
                      decoration: BoxDecoration(
                        color: AppColors.secondary,
                        borderRadius: BorderRadius.circular(22),
                      ),
                      child: const Icon(LucideIcons.mail_check,
                          color: AppColors.accent, size: 30),
                    ),
                    const SizedBox(height: 20),
                    Text('HESAP ERİŞİMİ', style: AppTypography.labelAccent()),
                    const SizedBox(height: 8),
                    Text(
                      'Şifrenizi yenileyin',
                      style: AppTypography.heading(
                        fontSize: 30,
                        color: AppColors.primary,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Hesabınıza bağlı e-posta adresini girin. Size güvenli bir şifre sıfırlama bağlantısı gönderelim.',
                      style: AppTypography.body(
                        fontSize: 15,
                        color: AppColors.mutedForeground,
                        height: 1.5,
                      ),
                    ),
                    const SizedBox(height: 24),
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: AppColors.card,
                        borderRadius: BorderRadius.circular(AppRadius.theme),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'E-posta adresi',
                            style: AppTypography.body(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 8),
                          TextField(
                            controller: TextEditingController(
                              text: 'ayse.yilmaz@novdoc.com',
                            ),
                            decoration: const InputDecoration(
                              prefixIcon: Icon(LucideIcons.mail, color: AppColors.accent),
                            ),
                          ),
                          const SizedBox(height: 16),
                          NovdocPrimaryButton(
                            label: 'Sıfırlama bağlantısı gönder',
                            icon: LucideIcons.arrow_up_right,
                            height: 56,
                            onPressed: () {},
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: NovdocSecondaryButton(
                label: 'Giriş ekranına dön',
                icon: LucideIcons.log_in,
                height: 56,
                onPressed: () => context.go('/login'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
