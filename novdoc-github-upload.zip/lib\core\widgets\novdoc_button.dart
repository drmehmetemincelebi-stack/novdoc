import 'package:flutter/material.dart';

import '../theme/app_colors.dart';
import '../theme/app_radius.dart';
import '../theme/app_typography.dart';

class NovdocPrimaryButton extends StatelessWidget {
  const NovdocPrimaryButton({
    super.key,
    required this.label,
    this.onPressed,
    this.icon,
    this.expanded = true,
    this.height = 48,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool expanded;
  final double height;

  @override
  Widget build(BuildContext context) {
    final child = Material(
      color: AppColors.primary,
      borderRadius: BorderRadius.circular(AppRadius.theme),
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(AppRadius.theme),
        child: SizedBox(
          height: height,
          width: expanded ? double.infinity : null,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: expanded ? MainAxisSize.max : MainAxisSize.min,
            children: [
              Text(
                label,
                style: AppTypography.heading(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: AppColors.primaryForeground,
                ),
              ),
              if (icon != null) ...[
                const SizedBox(width: 8),
                Icon(icon, color: AppColors.primaryForeground, size: 20),
              ],
            ],
          ),
        ),
      ),
    );
    return expanded ? child : child;
  }
}

class NovdocSecondaryButton extends StatelessWidget {
  const NovdocSecondaryButton({
    super.key,
    required this.label,
    this.onPressed,
    this.icon,
    this.expanded = true,
    this.outlined = false,
    this.height = 48,
    this.destructive = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool expanded;
  final bool outlined;
  final double height;
  final bool destructive;

  @override
  Widget build(BuildContext context) {
    final bg = outlined
        ? AppColors.card
        : (destructive ? AppColors.card : AppColors.secondary);
    final fg = destructive
        ? AppColors.destructive
        : (outlined ? AppColors.primary : AppColors.secondaryForeground);

    return Material(
      color: bg,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadius.theme),
        side: BorderSide(color: outlined ? AppColors.border : Colors.transparent),
      ),
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(AppRadius.theme),
        child: SizedBox(
          height: height,
          width: expanded ? double.infinity : null,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null) ...[
                Icon(icon, color: fg, size: 20),
                const SizedBox(width: 8),
              ],
              Text(
                label,
                style: AppTypography.heading(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: fg,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
