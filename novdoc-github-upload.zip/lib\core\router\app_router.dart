import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/admin/presentation/admin_dashboard_screen.dart';
import '../../features/auth/presentation/doctor_register_screen.dart';
import '../../features/auth/presentation/forgot_password_screen.dart';
import '../../features/auth/presentation/hospital_register_screen.dart';
import '../../features/auth/presentation/login_screen.dart';
import '../../features/auth/presentation/splash_screen.dart';
import '../../features/doctor/presentation/doctor_applications_screen.dart';
import '../../features/doctor/presentation/doctor_favorites_screen.dart';
import '../../features/doctor/presentation/doctor_home_screen.dart';
import '../../features/doctor/presentation/doctor_profile_edit_screen.dart';
import '../../features/doctor/presentation/doctor_profile_screen.dart';
import '../../features/hospital/presentation/hospital_applications_screen.dart';
import '../../features/hospital/presentation/hospital_dashboard_screen.dart';
import '../../features/hospital/presentation/hospital_listings_screen.dart';
import '../../features/hospital/presentation/hospital_new_listing_screen.dart';
import '../../features/hospital/presentation/hospital_profile_screen.dart';
import '../../features/jobs/presentation/job_detail_screen.dart';
import '../../features/jobs/presentation/job_filter_screen.dart';
import '../../features/notifications/presentation/notifications_screen.dart';
import '../../features/settings/presentation/settings_screen.dart';
import '../../features/system/presentation/error_screen.dart';
import '../../features/system/presentation/loading_screen.dart';
import '../../shared/models/user_role.dart';
import '../providers/app_session_provider.dart';
import '../widgets/novdoc_shell.dart';

final rootNavigatorKey = GlobalKey<NavigatorState>(debugLabel: 'root');

final routerProvider = Provider<GoRouter>((ref) {
  ref.watch(appSessionProvider);

  return GoRouter(
    navigatorKey: rootNavigatorKey,
    initialLocation: '/',
    routes: [
      GoRoute(path: '/', builder: (_, __) => const SplashScreen()),
      GoRoute(path: '/login', builder: (_, __) => const LoginScreen()),
      GoRoute(
        path: '/register/doctor',
        builder: (_, __) => const DoctorRegisterScreen(),
      ),
      GoRoute(
        path: '/register/hospital',
        builder: (_, __) => const HospitalRegisterScreen(),
      ),
      GoRoute(
        path: '/forgot-password',
        builder: (_, __) => const ForgotPasswordScreen(),
      ),
      GoRoute(
        path: '/notifications',
        parentNavigatorKey: rootNavigatorKey,
        builder: (_, __) => const NotificationsScreen(),
      ),
      GoRoute(
        path: '/settings',
        parentNavigatorKey: rootNavigatorKey,
        builder: (_, __) => const SettingsScreen(),
      ),
      GoRoute(
        path: '/admin',
        parentNavigatorKey: rootNavigatorKey,
        builder: (_, __) => const AdminDashboardScreen(),
      ),
      GoRoute(
        path: '/loading',
        parentNavigatorKey: rootNavigatorKey,
        builder: (_, __) => const LoadingScreen(),
      ),
      GoRoute(
        path: '/error',
        parentNavigatorKey: rootNavigatorKey,
        builder: (_, __) => const ErrorScreen(),
      ),
      GoRoute(
        path: '/doctor/job/:id',
        parentNavigatorKey: rootNavigatorKey,
        builder: (_, state) =>
            JobDetailScreen(jobId: state.pathParameters['id']!),
      ),
      GoRoute(
        path: '/doctor/filter',
        parentNavigatorKey: rootNavigatorKey,
        builder: (_, __) => const JobFilterScreen(),
      ),
      GoRoute(
        path: '/doctor/profile/edit',
        parentNavigatorKey: rootNavigatorKey,
        builder: (_, __) => const DoctorProfileEditScreen(),
      ),
      GoRoute(
        path: '/hospital/listings/new',
        parentNavigatorKey: rootNavigatorKey,
        builder: (_, __) => const HospitalNewListingScreen(),
      ),
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) => NovdocShell(
          navigationShell: navigationShell,
          role: UserRole.doctor,
        ),
        branches: [
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/doctor/home',
                pageBuilder: (_, __) => const NoTransitionPage(
                  child: DoctorHomeScreen(),
                ),
              ),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/doctor/favorites',
                pageBuilder: (_, __) => const NoTransitionPage(
                  child: DoctorFavoritesScreen(),
                ),
              ),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/doctor/applications',
                pageBuilder: (_, __) => const NoTransitionPage(
                  child: DoctorApplicationsScreen(),
                ),
              ),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/doctor/profile',
                pageBuilder: (_, __) => const NoTransitionPage(
                  child: DoctorProfileScreen(),
                ),
              ),
            ],
          ),
        ],
      ),
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) => NovdocShell(
          navigationShell: navigationShell,
          role: UserRole.hospital,
        ),
        branches: [
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/hospital/dashboard',
                pageBuilder: (_, __) => const NoTransitionPage(
                  child: HospitalDashboardScreen(),
                ),
              ),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/hospital/listings',
                pageBuilder: (_, __) => const NoTransitionPage(
                  child: HospitalListingsScreen(),
                ),
              ),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/hospital/applications',
                pageBuilder: (_, __) => const NoTransitionPage(
                  child: HospitalApplicationsScreen(),
                ),
              ),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/hospital/profile',
                pageBuilder: (_, __) => const NoTransitionPage(
                  child: HospitalProfileScreen(),
                ),
              ),
            ],
          ),
        ],
      ),
    ],
  );
});
