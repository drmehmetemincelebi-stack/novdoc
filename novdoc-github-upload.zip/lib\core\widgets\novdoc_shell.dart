import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../shared/models/user_role.dart';
import 'novdoc_bottom_nav.dart';

/// Sekmeler arası geçişte state korunur ([StatefulNavigationShell] + IndexedStack).
class NovdocShell extends ConsumerWidget {
  const NovdocShell({
    super.key,
    required this.navigationShell,
    required this.role,
  });

  final StatefulNavigationShell navigationShell;
  final UserRole role;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      body: navigationShell,
      bottomNavigationBar: NovdocBottomNav(
        role: role,
        currentIndex: navigationShell.currentIndex,
        onDestinationSelected: navigationShell.goBranch,
      ),
    );
  }
}
