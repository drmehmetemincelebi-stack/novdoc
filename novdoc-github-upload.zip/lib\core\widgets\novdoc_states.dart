import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../theme/app_colors.dart';
import '../theme/app_radius.dart';
import '../theme/app_typography.dart';
import 'novdoc_button.dart';
import 'novdoc_ui.dart' show NovdocCard;
  const NovdocEmptyState({
    super.key,
    required this.title,
    required this.description,
    this.imageUrl,
    this.primaryAction,
    this.primaryLabel,
    this.secondaryAction,
    this.secondaryLabel,
    this.accentLabel,
  });

  final String? accentLabel;
  final String title;
  final String description;
  final String? imageUrl;
  final String? primaryLabel;
  final VoidCallback? primaryAction;
  final String? secondaryLabel;
  final VoidCallback? secondaryAction;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (imageUrl != null)
              SizedBox(
                height: 220,
                child: CachedNetworkImage(imageUrl: imageUrl!, fit: BoxFit.contain),
              ),
            if (accentLabel != null) ...[
              const SizedBox(height: 16),
              Text(accentLabel!.toUpperCase(), style: AppTypography.labelAccent()),
            ],
            const SizedBox(height: 12),
            Text(
              title,
              textAlign: TextAlign.center,
              style: AppTypography.heading(fontSize: 28, color: AppColors.primary),
            ),
            const SizedBox(height: 12),
            Text(
              description,
              textAlign: TextAlign.center,
              style: AppTypography.body(
                fontSize: 15,
                color: AppColors.mutedForeground,
                height: 1.5,
              ),
            ),
            if (primaryLabel != null) ...[
              const SizedBox(height: 24),
              NovdocPrimaryButton(
                label: primaryLabel!,
                onPressed: primaryAction,
                height: 52,
              ),
            ],
            if (secondaryLabel != null) ...[
              const SizedBox(height: 12),
              NovdocSecondaryButton(
                label: secondaryLabel!,
                outlined: true,
                onPressed: secondaryAction,
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class NovdocErrorState extends StatelessWidget {
  const NovdocErrorState({
    super.key,
    required this.imageUrl,
    this.onRetry,
    this.onHome,
  });

  final String imageUrl;
  final VoidCallback? onRetry;
  final VoidCallback? onHome;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: NovdocEmptyState(
            accentLabel: 'Bağlantı kurulamadı',
            title: 'Bir şeyler ters gitti',
            description:
                'Verilerinizi şu anda yükleyemedik. Endişelenmeyin, hesabınız ve başvurularınız güvende.',
            imageUrl: imageUrl,
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              NovdocPrimaryButton(
                label: 'Tekrar Dene',
                icon: Icons.refresh,
                height: 56,
                onPressed: onRetry,
              ),
              const SizedBox(height: 12),
              NovdocSecondaryButton(
                label: 'Ana Sayfaya Dön',
                onPressed: onHome,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class NovdocLoadingSkeleton extends StatelessWidget {
  const NovdocLoadingSkeleton({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        _bar(width: 96),
        const SizedBox(height: 12),
        _bar(width: 240, height: 28),
        const SizedBox(height: 24),
        NovdocCard(
          child: Column(
            children: [
              Row(
                children: [
                  _box(56, 56, radius: 12),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _bar(width: 140),
                        const SizedBox(height: 8),
                        _bar(width: 100),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              _bar(),
              const SizedBox(height: 8),
              _bar(width: double.infinity),
              const SizedBox(height: 8),
              _bar(width: 200),
            ],
          ),
        ),
      ],
    );
  }

  Widget _bar({double width = double.infinity, double height = 12}) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        color: AppColors.muted,
        borderRadius: BorderRadius.circular(AppRadius.pill),
      ),
    );
  }

  Widget _box(double w, double h, {double radius = 8}) {
    return Container(
      width: w,
      height: h,
      decoration: BoxDecoration(
        color: AppColors.muted,
        borderRadius: BorderRadius.circular(radius),
      ),
    );
  }
}
