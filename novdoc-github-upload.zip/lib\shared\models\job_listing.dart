import 'package:flutter/material.dart';

class JobListing {
  const JobListing({
    required this.id,
    required this.title,
    required this.hospitalName,
    required this.city,
    required this.workType,
    required this.description,
    required this.publishedAgo,
    required this.logoLetter,
    required this.logoColor,
    this.badges = const [],
    this.footerLeft,
    this.footerRight,
    this.footerRightIsSuccess = false,
    this.salaryAvailable = false,
  });

  final String id;
  final String title;
  final String hospitalName;
  final String city;
  final String workType;
  final String description;
  final String publishedAgo;
  final String logoLetter;
  final Color logoColor;
  final List<JobBadge> badges;
  final String? footerLeft;
  final String? footerRight;
  final bool footerRightIsSuccess;
  final bool salaryAvailable;
}

class JobBadge {
  const JobBadge(this.label, this.variant);

  final String label;
  final JobBadgeVariant variant;
}

enum JobBadgeVariant { accent, success, destructive, secondary }
