import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../../core/providers/app_session_provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/novdoc_button.dart';
import '../../../core/widgets/novdoc_icon_button.dart';
import '../../../core/widgets/novdoc_ui.dart';

import '../../../shared/models/user_role.dart';

class DoctorRegisterScreen extends ConsumerStatefulWidget {
  const DoctorRegisterScreen({super.key});

  @override
  ConsumerState<DoctorRegisterScreen> createState() => _DoctorRegisterScreenState();
}

class _DoctorRegisterScreenState extends ConsumerState<DoctorRegisterScreen> {
  int _step = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.screenHorizontal,
            28,
            AppSpacing.screenHorizontal,
            24,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  NovdocIconButton(
                    icon: LucideIcons.arrow_left,
                    onPressed: () => context.pop(),
                    semanticLabel: 'Geri dön',
                  ),
                  Text(
                    'Doktor kaydı',
                    style: AppTypography.body(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: AppColors.mutedForeground,
                    ),
                  ),
                  const SizedBox(width: 44),
                ],
              ),
              const SizedBox(height: 28),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('ADIM ${_step + 1} / 3', style: AppTypography.labelAccent()),
                      const SizedBox(height: 4),
                      Text(
                        ['Temel Bilgiler', 'İletişim', 'Uzmanlık'][_step],
                        style: AppTypography.heading(fontSize: 24),
                      ),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: AppColors.secondary,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      '%${((_step + 1) / 3 * 100).round()} tamamlandı',
                      style: AppTypography.body(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: AppColors.secondaryForeground,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: (_step + 1) / 3,
                  minHeight: 6,
                  backgroundColor: AppColors.muted,
                  color: AppColors.primary,
                ),
              ),
              const SizedBox(height: 24),
              Expanded(
                child: SingleChildScrollView(
                  child: NovdocCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        if (_step == 0) ...[
                          _field('Ad', 'Elif'),
                          const SizedBox(height: 12),
                          _field('Soyad', 'Yılmaz'),
                          const SizedBox(height: 12),
                          _field('T.C. Kimlik No', '•••••••••••'),
                        ] else if (_step == 1) ...[
                          _field('E-posta', 'elif.yilmaz@novdoc.com'),
                          const SizedBox(height: 12),
                          _field('Telefon', '+90 532 000 00 00'),
                        ] else ...[
                          _field('Branş', 'Kardiyoloji'),
                          const SizedBox(height: 12),
                          _field('Deneyim (yıl)', '12'),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
              NovdocPrimaryButton(
                label: _step < 2 ? 'Devam Et' : 'Kaydı Tamamla',
                height: 52,
                onPressed: () {
                  if (_step < 2) {
                    setState(() => _step++);
                  } else {
                    ref.read(appSessionProvider.notifier).setRole(UserRole.doctor);
                    context.go('/doctor/home');
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _field(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: AppTypography.body(fontSize: 14, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        TextField(
          controller: TextEditingController(text: value),
          decoration: const InputDecoration(),
        ),
      ],
    );
  }
}
