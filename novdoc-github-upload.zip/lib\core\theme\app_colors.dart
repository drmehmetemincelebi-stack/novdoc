import 'package:flutter/material.dart';

abstract final class AppColors {
  static const background = Color(0xFFF7FBFC);
  static const foreground = Color(0xFF102A38);
  static const primary = Color(0xFF0B4F7A);
  static const primaryForeground = Color(0xFFFFFFFF);
  static const secondary = Color(0xFFE6F2F8);
  static const secondaryForeground = Color(0xFF0B4F7A);
  static const accent = Color(0xFF007F86);
  static const accentForeground = Color(0xFFFFFFFF);
  static const muted = Color(0xFFEEF4F6);
  static const mutedForeground = Color(0xFF527080);
  static const card = Color(0xFFFFFFFF);
  static const cardForeground = Color(0xFF102A38);
  static const border = Color(0xFFD7E5EA);
  static const input = Color(0xFFC7D9E0);
  static const destructive = Color(0xFFB4233C);
  static const destructiveForeground = Color(0xFFFFFFFF);
  static const success = Color(0xFF18794E);
  static const successForeground = Color(0xFFFFFFFF);
  static const chart1 = Color(0xFF0B4F7A);
  static const chart2 = Color(0xFF007F86);
  static const chart3 = Color(0xFF4C7598);
  static const chart4 = Color(0xFF7B5B9E);
  static const chart5 = Color(0xFFB66B3D);
}
