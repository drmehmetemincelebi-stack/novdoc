import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/novdoc_button.dart';
import '../../../core/widgets/novdoc_icon_button.dart';
import '../../../core/widgets/novdoc_ui.dart';

class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.screenHorizontal,
            24,
            AppSpacing.screenHorizontal,
            32,
          ),
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                NovdocIconButton(
                  icon: LucideIcons.arrow_left,
                  onPressed: () => context.pop(),
                  semanticLabel: 'Geri dön',
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppColors.success,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    children: [
                      const Icon(LucideIcons.shield_check,
                          size: 14, color: AppColors.successForeground),
                      const SizedBox(width: 6),
                      Text(
                        'Güvenli yönetici alanı',
                        style: AppTypography.body(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: AppColors.successForeground,
                        ),
                      ),
                    ],
                  ),
                ),
                NovdocIconButton(
                  icon: LucideIcons.more_horizontal,
                  onPressed: () {},
                  semanticLabel: 'Menü',
                ),
              ],
            ),
            const SizedBox(height: 20),
            Text('NOVDOC Yönetim Merkezi', style: AppTypography.labelAccent()),
            Text('Yönetici Paneli', style: AppTypography.heading(fontSize: 24)),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.primary,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Platform özeti',
                    style: AppTypography.body(
                      fontSize: 12,
                      color: AppColors.primaryForeground.withValues(alpha: 0.7),
                    ),
                  ),
                  Text(
                    '1.248',
                    style: AppTypography.heading(
                      fontSize: 28,
                      color: AppColors.primaryForeground,
                    ),
                  ),
                  Text(
                    'aktif sağlık profesyoneli',
                    style: AppTypography.body(
                      color: AppColors.primaryForeground.withValues(alpha: 0.8),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(child: _stat('12', 'Bekleyen kurum onayı')),
                const SizedBox(width: 12),
                Expanded(child: _stat('27', 'Bekleyen ilan kontrolü')),
              ],
            ),
            const SizedBox(height: 24),
            Text('İşlem kuyrukları', style: AppTypography.heading(fontSize: 18)),
            const SizedBox(height: 12),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: const [
                  NovdocFilterChip(label: 'Kurum Onayları 12', selected: true),
                  SizedBox(width: 8),
                  NovdocFilterChip(label: 'Doktor Onayları 18'),
                  SizedBox(width: 8),
                  NovdocFilterChip(label: 'İlan Kontrolleri 27'),
                ],
              ),
            ),
            const SizedBox(height: 16),
            NovdocCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Biruni Üniversite Hastanesi',
                    style: AppTypography.heading(fontSize: 15),
                  ),
                  Text(
                    'İstanbul · Özel hastane',
                    style: AppTypography.body(
                      fontSize: 12,
                      color: AppColors.mutedForeground,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: NovdocPrimaryButton(
                          label: 'Onayla',
                          height: 40,
                          onPressed: () {},
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: NovdocSecondaryButton(
                          label: 'İncele',
                          height: 40,
                          onPressed: () {},
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _stat(String value, String label) {
    return NovdocCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(value, style: AppTypography.heading(fontSize: 28)),
          Text(
            label,
            style: AppTypography.body(
              fontSize: 12,
              color: AppColors.mutedForeground,
            ),
          ),
        ],
      ),
    );
  }
}
