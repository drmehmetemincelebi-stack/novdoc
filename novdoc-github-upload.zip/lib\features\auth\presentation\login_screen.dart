import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../../core/providers/app_session_provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_radius.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/novdoc_button.dart';
import '../../../core/widgets/novdoc_icon_button.dart';
import '../../../shared/models/user_role.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  UserRole _role = UserRole.doctor;
  bool _obscure = true;

  void _login() {
    ref.read(appSessionProvider.notifier).setRole(_role);
    context.go(
      _role == UserRole.hospital ? '/hospital/dashboard' : '/doctor/home',
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.screenHorizontal,
            24,
            AppSpacing.screenHorizontal,
            32,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  NovdocIconButton(
                    icon: LucideIcons.arrow_left,
                    onPressed: () => context.go('/'),
                    semanticLabel: 'Geri dön',
                  ),
                  Row(
                    children: [
                      Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: AppColors.primary,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(LucideIcons.plus,
                            color: AppColors.primaryForeground, size: 18),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'NOVDOC',
                        style: AppTypography.heading(
                          fontSize: 19,
                          fontWeight: FontWeight.w800,
                          color: AppColors.primary,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(width: 44),
                ],
              ),
              const SizedBox(height: 40),
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: AppColors.secondary,
                  borderRadius: BorderRadius.circular(22),
                ),
                child: const Icon(LucideIcons.log_in, color: AppColors.accent, size: 30),
              ),
              const SizedBox(height: 20),
              Text('HESAP ERİŞİMİ', style: AppTypography.labelAccent()),
              const SizedBox(height: 8),
              Text(
                'Tekrar hoş geldiniz',
                style: AppTypography.heading(
                  fontSize: 30,
                  color: AppColors.primary,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'NOVDOC hesabınızla giriş yapın ve kariyer fırsatlarınıza kaldığınız yerden devam edin.',
                style: AppTypography.body(
                  fontSize: 15,
                  color: AppColors.mutedForeground,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: _RoleToggle(
                      label: 'Doktor',
                      selected: _role == UserRole.doctor,
                      onTap: () => setState(() => _role = UserRole.doctor),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _RoleToggle(
                      label: 'Hastane',
                      selected: _role == UserRole.hospital,
                      onTap: () => setState(() => _role = UserRole.hospital),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppColors.card,
                  borderRadius: BorderRadius.circular(AppRadius.theme),
                  border: Border.all(color: AppColors.border),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'E-posta adresi',
                      style: AppTypography.body(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 8),
                    _InputRow(
                      icon: LucideIcons.mail,
                      hint: 'ornek@novdoc.com',
                      keyboardType: TextInputType.emailAddress,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Şifre',
                      style: AppTypography.body(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 8),
                    _InputRow(
                      icon: LucideIcons.lock_keyhole,
                      hint: '••••••••',
                      obscure: _obscure,
                      trailing: IconButton(
                        icon: Icon(
                          _obscure ? LucideIcons.eye : LucideIcons.eye_off,
                          color: AppColors.mutedForeground,
                        ),
                        onPressed: () => setState(() => _obscure = !_obscure),
                      ),
                    ),
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton(
                        onPressed: () => context.push('/forgot-password'),
                        child: Text(
                          'Şifremi unuttum',
                          style: AppTypography.body(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: AppColors.accent,
                          ),
                        ),
                      ),
                    ),
                    NovdocPrimaryButton(
                      label: 'Giriş Yap',
                      height: 56,
                      icon: LucideIcons.arrow_up_right,
                      onPressed: _login,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.muted,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(LucideIcons.shield_check,
                        size: 18, color: AppColors.accent),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Giriş bilgileriniz uçtan uca şifrelenir. Paylaşılan cihazlarda oturumu kapatmayı unutmayın.',
                        style: AppTypography.body(
                          fontSize: 12,
                          color: AppColors.mutedForeground,
                          height: 1.45,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Hesabınız yok mu?',
                    style: AppTypography.body(
                      fontSize: 14,
                      color: AppColors.mutedForeground,
                    ),
                  ),
                  TextButton(
                    onPressed: () => context.push('/register/doctor'),
                    child: Text(
                      'Kayıt olun',
                      style: AppTypography.body(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: AppColors.accent,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RoleToggle extends StatelessWidget {
  const _RoleToggle({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: selected ? AppColors.primary : AppColors.card,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadius.theme),
        side: BorderSide(
          color: selected ? AppColors.primary : AppColors.border,
          width: selected ? 2 : 1,
        ),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppRadius.theme),
        child: SizedBox(
          height: 48,
          child: Center(
            child: Text(
              label,
              style: AppTypography.heading(
                fontSize: 14,
                color: selected
                    ? AppColors.primaryForeground
                    : AppColors.foreground,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _InputRow extends StatelessWidget {
  const _InputRow({
    required this.icon,
    required this.hint,
    this.obscure = false,
    this.trailing,
    this.keyboardType,
  });

  final IconData icon;
  final String hint;
  final bool obscure;
  final Widget? trailing;
  final TextInputType? keyboardType;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 56,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: AppColors.input.withValues(alpha: 0.3),
        borderRadius: BorderRadius.circular(AppRadius.theme),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Icon(icon, color: AppColors.accent, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: TextField(
              obscureText: obscure,
              keyboardType: keyboardType,
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: hint,
                hintStyle: AppTypography.body(color: AppColors.mutedForeground),
              ),
            ),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}
