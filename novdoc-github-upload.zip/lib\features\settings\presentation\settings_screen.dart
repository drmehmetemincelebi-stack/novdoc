import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../../core/providers/app_session_provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/novdoc_icon_button.dart';
import '../../../core/widgets/novdoc_ui.dart';
import '../../../shared/models/user_role.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.screenHorizontal,
            24,
            AppSpacing.screenHorizontal,
            32,
          ),
          children: [
            Row(
              children: [
                NovdocIconButton(
                  icon: LucideIcons.arrow_left,
                  onPressed: () => context.pop(),
                  semanticLabel: 'Geri dön',
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Hesabınız', style: AppTypography.labelAccent()),
                    Text('Ayarlar', style: AppTypography.heading(fontSize: 24)),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 28),
            Text('Hesap', style: AppTypography.heading(fontSize: 16)),
            const SizedBox(height: 12),
            NovdocCard(
              padding: EdgeInsets.zero,
              child: Column(
                children: [
                  NovdocSettingsTile(
                    icon: LucideIcons.mail_check,
                    title: 'E-posta adresi',
                    subtitle: 'ayse.demir@ornek.com',
                    trailing: _verified(),
                  ),
                  NovdocSettingsTile(
                    icon: LucideIcons.phone,
                    title: 'Telefon numarası',
                    subtitle: '+90 532 418 27 64',
                    trailing: _verified(),
                    showDivider: false,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Text('Güvenlik ve gizlilik', style: AppTypography.heading(fontSize: 16)),
            const SizedBox(height: 12),
            NovdocCard(
              padding: EdgeInsets.zero,
              child: Column(
                children: [
                  NovdocSettingsTile(
                    icon: LucideIcons.lock_keyhole,
                    title: 'Şifreyi değiştir',
                    onTap: () => context.push('/forgot-password'),
                  ),
                  NovdocSettingsTile(
                    icon: LucideIcons.eye,
                    title: 'Gizlilik ayarları',
                    showDivider: false,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            NovdocCard(
              padding: EdgeInsets.zero,
              child: NovdocSettingsTile(
                icon: LucideIcons.layout_dashboard,
                title: 'Yönetici paneli (demo)',
                subtitle: 'Platform onay merkezi',
                onTap: () => context.push('/admin'),
                showDivider: false,
              ),
            ),
            const SizedBox(height: 24),
            Material(
              color: AppColors.card,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
                side: const BorderSide(color: AppColors.border),
              ),
              child: InkWell(
                onTap: () {
                  ref.read(appSessionProvider.notifier).setRole(UserRole.guest);
                  context.go('/');
                },
                borderRadius: BorderRadius.circular(16),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(LucideIcons.log_out, color: AppColors.destructive),
                      const SizedBox(width: 8),
                      Text(
                        'Çıkış yap',
                        style: AppTypography.body(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: AppColors.destructive,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'NOVDOC · Sürüm 2.4.1',
              textAlign: TextAlign.center,
              style: AppTypography.body(
                fontSize: 12,
                color: AppColors.mutedForeground,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _verified() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: AppColors.success,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        'Doğrulandı',
        style: AppTypography.body(
          fontSize: 10,
          fontWeight: FontWeight.w700,
          color: AppColors.successForeground,
        ),
      ),
    );
  }
}
