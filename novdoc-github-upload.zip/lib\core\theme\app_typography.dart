import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'app_colors.dart';

abstract final class AppTypography {
  static TextStyle heading({
    double? fontSize,
    FontWeight fontWeight = FontWeight.w700,
    Color? color,
    double? height,
    double letterSpacing = -0.02,
  }) {
    return GoogleFonts.manrope(
      fontSize: fontSize,
      fontWeight: fontWeight,
      color: color ?? AppColors.foreground,
      height: height,
      letterSpacing: letterSpacing,
    );
  }

  static TextStyle body({
    double? fontSize,
    FontWeight fontWeight = FontWeight.w400,
    Color? color,
    double? height,
  }) {
    return GoogleFonts.inter(
      fontSize: fontSize,
      fontWeight: fontWeight,
      color: color ?? AppColors.foreground,
      height: height,
    );
  }

  static TextStyle labelAccent() {
    return GoogleFonts.inter(
      fontSize: 12,
      fontWeight: FontWeight.w600,
      letterSpacing: 1.4,
      color: AppColors.accent,
    );
  }

  static TextTheme textTheme = TextTheme(
    displayLarge: heading(fontSize: 30, fontWeight: FontWeight.w800),
    headlineLarge: heading(fontSize: 27),
    headlineMedium: heading(fontSize: 24),
    titleLarge: heading(fontSize: 20),
    titleMedium: heading(fontSize: 17, fontWeight: FontWeight.w700),
    bodyLarge: body(fontSize: 15, height: 1.5),
    bodyMedium: body(fontSize: 14, height: 1.45),
    bodySmall: body(fontSize: 12, color: AppColors.mutedForeground),
    labelLarge: body(fontSize: 14, fontWeight: FontWeight.w700),
    labelMedium: body(fontSize: 12, fontWeight: FontWeight.w600),
  );
}
