import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../../core/constants/app_assets.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/novdoc_button.dart';
import '../../../core/widgets/novdoc_ui.dart';

class HospitalApplicationsScreen extends StatelessWidget {
  const HospitalApplicationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.screenHorizontal,
            24,
            AppSpacing.screenHorizontal,
            120,
          ),
          children: [
            Text('Gelen Başvurular', style: AppTypography.heading(fontSize: 24)),
            const SizedBox(height: 8),
            Text(
              'Nitelikli hekim adaylarını hızlıca değerlendirin.',
              style: AppTypography.body(color: AppColors.mutedForeground),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColors.primary,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Toplam başvuru',
                          style: AppTypography.body(
                            fontSize: 12,
                            color: AppColors.primaryForeground.withValues(alpha: 0.75),
                          ),
                        ),
                        Text(
                          '24',
                          style: AppTypography.heading(
                            fontSize: 32,
                            color: AppColors.primaryForeground,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: NovdocCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Yeni başvuru',
                          style: AppTypography.body(
                            fontSize: 12,
                            color: AppColors.mutedForeground,
                          ),
                        ),
                        Text('8', style: AppTypography.heading(fontSize: 32)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: const [
                  NovdocFilterChip(label: 'Tümü 24', selected: true),
                  SizedBox(width: 8),
                  NovdocFilterChip(label: 'Yeni 8'),
                  SizedBox(width: 8),
                  NovdocFilterChip(label: 'İnceleniyor 6'),
                ],
              ),
            ),
            const SizedBox(height: 24),
            _candidate(
              'Dr. Elif Yılmaz',
              'Kardiyoloji Uzmanı',
              AppAssets.candidate1,
              'Yeni',
            ),
            const SizedBox(height: 12),
            _candidate(
              'Dr. Mert Kaya',
              'Beyin ve Sinir Cerrahisi',
              AppAssets.candidate2,
              'İnceleniyor',
            ),
          ],
        ),
      ),
    );
  }

  Widget _candidate(String name, String specialty, String photo, String status) {
    return NovdocCard(
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: CachedNetworkImage(imageUrl: photo, width: 56, height: 56, fit: BoxFit.cover),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(name, style: AppTypography.heading(fontSize: 15)),
                    Text(
                      specialty,
                      style: AppTypography.body(
                        fontSize: 14,
                        color: AppColors.mutedForeground,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: AppColors.secondary,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        status,
                        style: AppTypography.body(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: AppColors.secondaryForeground,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          NovdocPrimaryButton(label: 'Profili Görüntüle', height: 44, onPressed: () {}),
          const SizedBox(height: 8),
          NovdocSecondaryButton(
            label: 'CV’yi İndir',
            icon: LucideIcons.download,
            height: 40,
            onPressed: () {},
          ),
        ],
      ),
    );
  }
}
