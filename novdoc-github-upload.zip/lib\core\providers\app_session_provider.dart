import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../shared/models/user_role.dart';

class AppSession {
  const AppSession({
    this.role = UserRole.guest,
    this.favoritesEmpty = false,
    this.applicationsEmpty = false,
    this.searchEmpty = false,
  });

  final UserRole role;
  final bool favoritesEmpty;
  final bool applicationsEmpty;
  final bool searchEmpty;

  AppSession copyWith({
    UserRole? role,
    bool? favoritesEmpty,
    bool? applicationsEmpty,
    bool? searchEmpty,
  }) {
    return AppSession(
      role: role ?? this.role,
      favoritesEmpty: favoritesEmpty ?? this.favoritesEmpty,
      applicationsEmpty: applicationsEmpty ?? this.applicationsEmpty,
      searchEmpty: searchEmpty ?? this.searchEmpty,
    );
  }
}

class AppSessionNotifier extends Notifier<AppSession> {
  @override
  AppSession build() => const AppSession();

  void setRole(UserRole role) => state = state.copyWith(role: role);

  void toggleFavoritesEmpty() =>
      state = state.copyWith(favoritesEmpty: !state.favoritesEmpty);

  void toggleApplicationsEmpty() =>
      state = state.copyWith(applicationsEmpty: !state.applicationsEmpty);

  void toggleSearchEmpty() =>
      state = state.copyWith(searchEmpty: !state.searchEmpty);
}

final appSessionProvider =
    NotifierProvider<AppSessionNotifier, AppSession>(AppSessionNotifier.new);
