import 'package:flutter/material.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../shared/models/user_role.dart';
import '../theme/app_colors.dart';
import '../theme/app_typography.dart';

class NovdocBottomNav extends StatelessWidget {
  const NovdocBottomNav({
    super.key,
    required this.role,
    required this.currentIndex,
    required this.onDestinationSelected,
  });

  final UserRole role;
  final int currentIndex;
  final ValueChanged<int> onDestinationSelected;

  @override
  Widget build(BuildContext context) {
    final items = role == UserRole.hospital ? _hospitalItems : _doctorItems;

    return Container(
      decoration: BoxDecoration(
        color: AppColors.card.withValues(alpha: 0.95),
        border: const Border(top: BorderSide(color: AppColors.border)),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 12),
          child: Row(
            children: [
              for (var i = 0; i < items.length; i++)
                Expanded(
                  child: _TabItem(
                    item: items[i],
                    selected: currentIndex == i,
                    onTap: () => onDestinationSelected(i),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  static const _doctorItems = [
    _NavItem('Ana Sayfa', LucideIcons.house),
    _NavItem('Favoriler', LucideIcons.heart),
    _NavItem('Başvurularım', LucideIcons.clipboard_list),
    _NavItem('Profil', LucideIcons.user_round),
  ];

  static const _hospitalItems = [
    _NavItem('Panel', LucideIcons.layout_dashboard),
    _NavItem('İlanlarım', LucideIcons.clipboard_pen_line),
    _NavItem('Başvurular', LucideIcons.users_round),
    _NavItem('Profil', LucideIcons.building_2),
  ];
}

class _NavItem {
  const _NavItem(this.label, this.icon);
  final String label;
  final IconData icon;
}

class _TabItem extends StatelessWidget {
  const _TabItem({
    required this.item,
    required this.selected,
    required this.onTap,
  });

  final _NavItem item;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = selected ? AppColors.primary : AppColors.mutedForeground;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            height: 32,
            width: 44,
            decoration: selected
                ? BoxDecoration(
                    color: AppColors.secondary,
                    borderRadius: BorderRadius.circular(22),
                  )
                : null,
            alignment: Alignment.center,
            child: Icon(item.icon, size: 22, color: color),
          ),
          const SizedBox(height: 4),
          Text(
            item.label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: AppTypography.body(
              fontSize: 10,
              fontWeight: selected ? FontWeight.w700 : FontWeight.w600,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
