# Backend entegrasyonu (sonraki adım)

FlutterFlow veya ek program gerekmez. Sadece `JobsDataSource` arayüzünü gerçek API ile doldurun.

## Supabase (görseller zaten Supabase CDN’de)

1. Supabase projesi oluşturun (ücretsiz tier).
2. `jobs`, `applications`, `profiles` tabloları.
3. Yeni sınıf: `SupabaseJobsDataSource implements JobsDataSource`.
4. `jobsDataSourceProvider` içinde mock yerine Supabase’i inject edin.

## Ortam değişkenleri

```
SUPABASE_URL=
SUPABASE_ANON_KEY=
```

`.env` dosyasını **commit etmeyin**. CI’da GitHub Secrets kullanın.

## Auth

Giriş ekranı hazır; `AppSessionNotifier.setRole` yerine Supabase Auth session + profil rolü okunur.

Cursor chat’te “Supabase jobs datasource ekle” diyerek AI ile adım adım ilerleyebilirsiniz.
