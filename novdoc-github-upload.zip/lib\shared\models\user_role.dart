enum UserRole { guest, doctor, hospital, admin }

enum ApplicationStatus { yeni, inceleniyor, mulakat, kisaListe, olumlu, red }
