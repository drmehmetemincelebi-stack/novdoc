import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../../core/providers/app_session_provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/novdoc_button.dart';
import '../../../core/widgets/novdoc_icon_button.dart';
import '../../../core/widgets/novdoc_ui.dart';

import '../../../shared/models/user_role.dart';

class HospitalRegisterScreen extends ConsumerWidget {
  const HospitalRegisterScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.screenHorizontal,
            28,
            AppSpacing.screenHorizontal,
            24,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              NovdocIconButton(
                icon: LucideIcons.arrow_left,
                onPressed: () => context.pop(),
                semanticLabel: 'Geri dön',
              ),
              const SizedBox(height: 28),
              Text('KURUM KAYDI', style: AppTypography.labelAccent()),
              const SizedBox(height: 8),
              Text(
                'Hastanenizi\nNOVDOC’a taşıyın',
                style: AppTypography.heading(fontSize: 28, height: 1.15),
              ),
              const SizedBox(height: 12),
              Text(
                'Doğrulanmış kurum profilinizle nitelikli hekimlere güvenle ulaşın.',
                style: AppTypography.body(
                  fontSize: 15,
                  color: AppColors.mutedForeground,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 24),
              Expanded(
                child: SingleChildScrollView(
                  child: NovdocCard(
                    child: Column(
                      children: [
                        _field('Kurum adı', 'Acıbadem Maslak Hastanesi'),
                        const SizedBox(height: 12),
                        _field('Vergi numarası', ''),
                        const SizedBox(height: 12),
                        _field('Yetkili kişi', ''),
                        const SizedBox(height: 12),
                        _field('Kurumsal e-posta', ''),
                      ],
                    ),
                  ),
                ),
              ),
              NovdocPrimaryButton(
                label: 'Kurum kaydını başlat',
                height: 52,
                onPressed: () {
                  ref.read(appSessionProvider.notifier).setRole(UserRole.hospital);
                  context.go('/hospital/dashboard');
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _field(String label, String hint) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: AppTypography.body(fontSize: 14, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        TextField(decoration: InputDecoration(hintText: hint.isEmpty ? null : hint)),
      ],
    );
  }
}
