import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../../core/constants/app_assets.dart';
import '../../../core/providers/app_session_provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_radius.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/novdoc_button.dart';
import '../../../core/widgets/novdoc_icon_button.dart';
import '../../../shared/models/user_role.dart';

class SplashScreen extends ConsumerWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.screenHorizontal,
            24,
            AppSpacing.screenHorizontal,
            28,
          ),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  NovdocIconButton(
                    icon: LucideIcons.arrow_left,
                    semanticLabel: 'Geri dön',
                    onPressed: () {},
                  ),
                  Row(
                    children: [
                      Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: AppColors.primary,
                          borderRadius: BorderRadius.circular(AppRadius.theme),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          'N',
                          style: AppTypography.heading(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            color: AppColors.primaryForeground,
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Text(
                        'NOVDOC',
                        style: AppTypography.heading(
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                          color: AppColors.primary,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(width: 44),
                ],
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const SizedBox(height: 36),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(AppRadius.theme),
                      child: Stack(
                        children: [
                          Container(
                            color: AppColors.secondary,
                            padding: const EdgeInsets.fromLTRB(24, 28, 24, 20),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'NOVDOC’A HOŞ GELDİNİZ',
                                  style: AppTypography.labelAccent(),
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  'Kariyeriniz için doğru bağlantı.',
                                  style: AppTypography.heading(
                                    fontSize: 30,
                                    fontWeight: FontWeight.w800,
                                    color: AppColors.primary,
                                    height: 1.12,
                                  ),
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  'Doktorlar ve sağlık kuruluşları için güvenilir, hızlı ve profesyonel kariyer platformu.',
                                  style: AppTypography.body(
                                    fontSize: 14,
                                    color: AppColors.mutedForeground,
                                    height: 1.4,
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.centerRight,
                                  child: CachedNetworkImage(
                                    imageUrl: AppAssets.splashIllustration,
                                    height: 160,
                                    fit: BoxFit.contain,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 32),
                    Text(
                      'Nasıl devam etmek istersiniz?',
                      style: AppTypography.heading(fontSize: 20),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Size uygun deneyimi seçin.',
                      style: AppTypography.body(
                        fontSize: 14,
                        color: AppColors.mutedForeground,
                      ),
                    ),
                    const SizedBox(height: 16),
                    _RoleCard(
                      primary: true,
                      icon: LucideIcons.user_round,
                      title: 'Doktor Olarak Devam Et',
                      subtitle:
                          'Yeni fırsatları keşfedin, kariyerinizi büyütün.',
                      onTap: () {
                        ref.read(appSessionProvider.notifier).setRole(UserRole.doctor);
                        context.push('/register/doctor');
                      },
                    ),
                    const SizedBox(height: 12),
                    _RoleCard(
                      primary: false,
                      icon: LucideIcons.building_2,
                      title: 'Hastane Olarak Devam Et',
                      subtitle: 'Nitelikli hekimlere hızlıca ulaşın.',
                      onTap: () {
                        ref
                            .read(appSessionProvider.notifier)
                            .setRole(UserRole.hospital);
                        context.push('/register/hospital');
                      },
                    ),
                    const Spacer(),
                    Row(
                      children: [
                        const Expanded(child: Divider(color: AppColors.border)),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          child: Text(
                            'Zaten hesabınız var mı?',
                            style: AppTypography.body(
                              fontSize: 12,
                              color: AppColors.mutedForeground,
                            ),
                          ),
                        ),
                        const Expanded(child: Divider(color: AppColors.border)),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: NovdocSecondaryButton(
                            label: 'Giriş Yap',
                            onPressed: () => context.push('/login'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: NovdocSecondaryButton(
                            label: 'Kayıt Ol',
                            outlined: true,
                            onPressed: () => context.push('/register/doctor'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(LucideIcons.shield_check,
                            size: 16, color: AppColors.success),
                        const SizedBox(width: 8),
                        Text(
                          'Bilgileriniz güvenle korunur',
                          style: AppTypography.body(
                            fontSize: 11,
                            color: AppColors.mutedForeground,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RoleCard extends StatelessWidget {
  const _RoleCard({
    required this.primary,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final bool primary;
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: primary ? AppColors.primary : AppColors.card,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadius.theme),
        side: primary
            ? BorderSide.none
            : const BorderSide(color: AppColors.border),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppRadius.theme),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: primary
                      ? Colors.white.withValues(alpha: 0.15)
                      : AppColors.secondary,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(
                  icon,
                  color: primary ? AppColors.primaryForeground : AppColors.primary,
                  size: 24,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: AppTypography.heading(
                        fontSize: 16,
                        color: primary
                            ? AppColors.primaryForeground
                            : AppColors.primary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: AppTypography.body(
                        fontSize: 12,
                        color: primary
                            ? AppColors.primaryForeground.withValues(alpha: 0.75)
                            : AppColors.mutedForeground,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(
                LucideIcons.arrow_up_right,
                color: primary ? AppColors.primaryForeground : AppColors.primary,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
