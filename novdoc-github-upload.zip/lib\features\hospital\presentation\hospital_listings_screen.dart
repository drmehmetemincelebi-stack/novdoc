import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/novdoc_button.dart';
import '../../../core/widgets/novdoc_ui.dart';

class HospitalListingsScreen extends StatelessWidget {
  const HospitalListingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.screenHorizontal,
            24,
            AppSpacing.screenHorizontal,
            120,
          ),
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('İlanlarım', style: AppTypography.heading(fontSize: 24)),
                IconButton(
                  onPressed: () => context.push('/hospital/listings/new'),
                  icon: const Icon(LucideIcons.plus, color: AppColors.primary),
                ),
              ],
            ),
            const SizedBox(height: 16),
            for (final item in _listings)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: NovdocCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item.title, style: AppTypography.heading(fontSize: 16)),
                      const SizedBox(height: 4),
                      Text(
                        '${item.applicants} başvuru • ${item.status}',
                        style: AppTypography.body(
                          fontSize: 13,
                          color: AppColors.mutedForeground,
                        ),
                      ),
                      const SizedBox(height: 12),
                      NovdocSecondaryButton(
                        label: 'Düzenle',
                        outlined: true,
                        height: 40,
                        onPressed: () {},
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  static const _listings = [
    _Listing('Kardiyoloji Uzmanı', 24, 'Yayında'),
    _Listing('Acil Tıp Uzmanı', 12, 'Taslak'),
  ];
}

class _Listing {
  const _Listing(this.title, this.applicants, this.status);
  final String title;
  final int applicants;
  final String status;
}
