abstract final class AppAssets {
  static const _base =
      'https://fwtngjyirchhhysukjxi.supabase.co/storage/v1/object/public/project-images/9d130cb7-99a5-429c-884d-0a5700f4ce98';

  static const splashIllustration = '$_base/73da4fb8-f638-470d-bcd8-17d9127c617d.png';
  static const jobHero = '$_base/011d8345-b5b4-46ff-b627-4967e53ba0bd.png';
  static const doctorProfile = '$_base/29a5109d-0062-4cd4-9068-17e59e368ca9.png';
  static const doctorProfileEdit = '$_base/3ee1baca-2f2b-4ce3-a4a2-665813995f51.png';
  static const emptyFavorites = '$_base/cfd1898b-457d-4f33-8c6f-76461a4ec5d6.png';
  static const errorIllustration = '$_base/84db48be-d2cc-4567-8913-06f25b22a723.png';
  static const candidate1 = '$_base/2e3e366d-aba0-4c1e-93b5-48c94ac8cf0b.png';
  static const candidate2 = '$_base/2c83a31b-9d9c-4cc8-b9f2-608a988e67a6.png';
  static const candidate3 = '$_base/28bee58b-9e6f-40ad-8b93-82ce150c11f9.png';
}
