import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../../core/providers/app_session_provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/job_listing_card.dart';
import '../../../core/widgets/novdoc_icon_button.dart';
import '../../../core/widgets/novdoc_ui.dart';
import '../../../shared/models/job_listing.dart';
import '../../../shared/mock/mock_data.dart';
import '../../../shared/repositories/jobs_repository.dart';
import '../../../core/widgets/novdoc_states.dart';

class DoctorHomeScreen extends ConsumerWidget {
  const DoctorHomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final empty = ref.watch(appSessionProvider.select((s) => s.searchEmpty));
    final jobsAsync = ref.watch(recommendedJobsProvider);

    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: empty
            ? _EmptySearch(onClear: () {
                ref.read(appSessionProvider.notifier).toggleSearchEmpty();
              })
            : jobsAsync.when(
                loading: () => const NovdocLoadingSkeleton(),
                error: (_, __) => _JobsError(
                  onRetry: () => ref.invalidate(recommendedJobsProvider),
                ),
                data: (jobs) => _DoctorHomeContent(jobs: jobs),
              ),
      ),
    );
  }
}

class _JobsError extends StatelessWidget {
  const _JobsError({required this.onRetry});

  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'İlanlar yüklenemedi',
              style: AppTypography.heading(fontSize: 22),
            ),
            const SizedBox(height: 12),
            ElevatedButton(onPressed: onRetry, child: const Text('Tekrar dene')),
          ],
        ),
      ),
    );
  }
}

class _DoctorHomeContent extends StatelessWidget {
  const _DoctorHomeContent({required this.jobs});

  final List<JobListing> jobs;

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
                slivers: [
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(
                        AppSpacing.screenHorizontal,
                        28,
                        AppSpacing.screenHorizontal,
                        0,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'NOVDOC • Doktor hesabı',
                                      style: AppTypography.labelAccent(),
                                    ),
                                    const SizedBox(height: 8),
                                    Text(
                                      'Merhaba ${MockData.doctorName}',
                                      style: AppTypography.heading(fontSize: 27),
                                    ),
                                    const SizedBox(height: 4),
                                    RichText(
                                      text: TextSpan(
                                        style: AppTypography.body(
                                          fontSize: 14,
                                          color: AppColors.mutedForeground,
                                        ),
                                        children: const [
                                          TextSpan(
                                            text: 'Bugün size uygun ',
                                          ),
                                          TextSpan(
                                            text: '14 yeni ilan',
                                            style: TextStyle(
                                              fontWeight: FontWeight.w700,
                                              color: AppColors.primary,
                                            ),
                                          ),
                                          TextSpan(text: ' bulundu.'),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Stack(
                                children: [
                                  NovdocIconButton(
                                    icon: LucideIcons.bell,
                                    semanticLabel: 'Bildirimler',
                                    onPressed: () => context.push('/notifications'),
                                  ),
                                  Positioned(
                                    right: 10,
                                    top: 10,
                                    child: Container(
                                      width: 8,
                                      height: 8,
                                      decoration: BoxDecoration(
                                        color: AppColors.accent,
                                        shape: BoxShape.circle,
                                        border: Border.all(
                                          color: AppColors.card,
                                          width: 2,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(height: 24),
                          Row(
                            children: [
                              Expanded(
                                child: Material(
                                  color: AppColors.card,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16),
                                    side: const BorderSide(
                                      color: Color(0x4D0B4F7A),
                                    ),
                                  ),
                                  child: InkWell(
                                    onTap: () {},
                                    borderRadius: BorderRadius.circular(16),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 16,
                                        vertical: 14,
                                      ),
                                      child: Row(
                                        children: [
                                          const Icon(LucideIcons.search,
                                              color: AppColors.primary),
                                          const SizedBox(width: 12),
                                          Expanded(
                                            child: Text(
                                              'Kardiyoloji, şehir veya hastane ara',
                                              style: AppTypography.body(
                                                fontSize: 15,
                                                fontWeight: FontWeight.w500,
                                              ),
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Material(
                                color: AppColors.primary,
                                borderRadius: BorderRadius.circular(16),
                                child: InkWell(
                                  onTap: () => context.push('/doctor/filter'),
                                  borderRadius: BorderRadius.circular(16),
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 16,
                                      vertical: 14,
                                    ),
                                    child: Row(
                                      children: [
                                        const Icon(LucideIcons.sliders_horizontal,
                                            color: AppColors.primaryForeground,
                                            size: 18),
                                        const SizedBox(width: 8),
                                        Text(
                                          'Filtrele',
                                          style: AppTypography.body(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w700,
                                            color: AppColors.primaryForeground,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 20),
                          SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Row(
                              children: const [
                                NovdocFilterChip(
                                  label: 'Şehir',
                                  selected: true,
                                  icon: LucideIcons.map_pin,
                                ),
                                SizedBox(width: 8),
                                NovdocFilterChip(
                                  label: 'Branş',
                                  icon: LucideIcons.stethoscope,
                                ),
                                SizedBox(width: 8),
                                NovdocFilterChip(label: 'Tam zamanlı'),
                                SizedBox(width: 8),
                                NovdocFilterChip(label: 'Yarı zamanlı'),
                              ],
                            ),
                          ),
                          const SizedBox(height: 28),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Size özel seçildi'.toUpperCase(),
                                    style: AppTypography.labelAccent(),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    'Önerilen ilanlar',
                                    style: AppTypography.heading(fontSize: 20),
                                  ),
                                ],
                              ),
                              TextButton(
                                onPressed: () {},
                                child: const Text('Tümünü gör →'),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(
                      AppSpacing.screenHorizontal,
                      16,
                      AppSpacing.screenHorizontal,
                      120,
                    ),
                    sliver: SliverList(
                      delegate: SliverChildBuilderDelegate(
                        (context, i) => RepaintBoundary(
                          child: Padding(
                            padding: const EdgeInsets.only(bottom: 16),
                            child: JobListingCard(job: jobs[i]),
                          ),
                        ),
                        childCount: jobs.length,
                      ),
                    ),
                  ),
                ],
    );
  }
}

class _EmptySearch extends StatelessWidget {
  const _EmptySearch({required this.onClear});

  final VoidCallback onClear;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Aramanızla eşleşen ilan bulunamadı',
              textAlign: TextAlign.center,
              style: AppTypography.heading(fontSize: 26),
            ),
            const SizedBox(height: 12),
            Text(
              'Filtreleri genişleterek daha fazla fırsat keşfedebilirsiniz.',
              textAlign: TextAlign.center,
              style: AppTypography.body(color: AppColors.mutedForeground),
            ),
            const SizedBox(height: 24),
            ElevatedButton(onPressed: onClear, child: const Text('Filtreleri temizle')),
          ],
        ),
      ),
    );
  }
}
