import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

import 'app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  GoogleFonts.config.allowRuntimeFetching = true;
  PaintingBinding.instance.imageCache.maximumSizeBytes = 48 << 20;
  runApp(const ProviderScope(child: NovdocApp()));
}
