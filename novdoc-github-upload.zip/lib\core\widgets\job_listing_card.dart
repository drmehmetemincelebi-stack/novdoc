import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../shared/models/job_listing.dart';
import '../theme/app_colors.dart';
import '../theme/app_typography.dart';
import 'novdoc_button.dart';
import 'novdoc_ui.dart';

class JobListingCard extends StatelessWidget {
  const JobListingCard({super.key, required this.job});

  final JobListing job;

  @override
  Widget build(BuildContext context) {
    return NovdocCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      for (final b in job.badges) ...[
                        NovdocBadge(badge: b),
                        const SizedBox(width: 8),
                      ],
                    ],
                  ),
                ),
              ),
              Material(
                color: AppColors.muted,
                shape: const CircleBorder(),
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: () {},
                  child: const Padding(
                    padding: EdgeInsets.all(8),
                    child: Icon(LucideIcons.heart, color: AppColors.primary, size: 20),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      job.title,
                      style: AppTypography.body(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: AppColors.accent,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      job.hospitalName,
                      style: AppTypography.heading(fontSize: 17),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 12,
                      runSpacing: 4,
                      children: [
                        _meta(LucideIcons.map_pin, job.city),
                        _meta(LucideIcons.briefcase, job.workType),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: AppColors.card,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.border),
                ),
                alignment: Alignment.center,
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: job.logoColor,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    job.logoLetter,
                    style: AppTypography.heading(
                      fontSize: 15,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            job.description,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: AppTypography.body(
              fontSize: 14,
              color: AppColors.mutedForeground,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 16),
          const Divider(color: AppColors.border, height: 1),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              if (job.footerLeft != null)
                Text(
                  job.footerLeft!,
                  style: AppTypography.body(fontSize: 12, color: AppColors.mutedForeground),
                ),
              if (job.footerRight != null)
                Text(
                  job.footerRight!,
                  style: AppTypography.body(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: job.footerRightIsSuccess
                        ? AppColors.success
                        : AppColors.primary,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: NovdocPrimaryButton(
                  label: 'Başvur',
                  height: 44,
                  onPressed: () => context.push('/doctor/job/${job.id}'),
                ),
              ),
              const SizedBox(width: 8),
              NovdocSecondaryButton(
                label: 'Detayları Gör',
                expanded: false,
                height: 44,
                onPressed: () => context.push('/doctor/job/${job.id}'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _meta(IconData icon, String text) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 14, color: AppColors.accent),
        const SizedBox(width: 4),
        Text(
          text,
          style: AppTypography.body(
            fontSize: 12,
            fontWeight: FontWeight.w500,
            color: AppColors.mutedForeground,
          ),
        ),
      ],
    );
  }
}
