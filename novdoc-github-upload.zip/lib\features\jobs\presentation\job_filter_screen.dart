import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/novdoc_button.dart';
import '../../../core/widgets/novdoc_icon_button.dart';
import '../../../core/widgets/novdoc_ui.dart';

class JobFilterScreen extends StatelessWidget {
  const JobFilterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.screenHorizontal,
                28,
                AppSpacing.screenHorizontal,
                16,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  NovdocIconButton(
                    icon: LucideIcons.arrow_left,
                    onPressed: () => context.pop(),
                    semanticLabel: 'Geri dön',
                  ),
                  Text('Filtreler', style: AppTypography.heading(fontSize: 20)),
                  TextButton(
                    onPressed: () {},
                    child: Text(
                      'Temizle',
                      style: AppTypography.body(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: AppColors.accent,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(
                  AppSpacing.screenHorizontal,
                  0,
                  AppSpacing.screenHorizontal,
                  24,
                ),
                children: [
                  _section(
                    'Şehir',
                    LucideIcons.map_pin,
                    chips: ['İstanbul', 'Ankara', 'İzmir', 'Antalya'],
                    selected: 0,
                  ),
                  const SizedBox(height: 16),
                  _section(
                    'Branş',
                    LucideIcons.stethoscope,
                    chips: [
                      'Tüm branşlar',
                      'Kardiyoloji',
                      'Genel Cerrahi',
                      'Acil Tıp',
                    ],
                    selected: 0,
                  ),
                  const SizedBox(height: 16),
                  NovdocCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Çalışma şekli', style: AppTypography.heading(fontSize: 16)),
                        const SizedBox(height: 12),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: const [
                            NovdocFilterChip(label: 'Tam zamanlı', selected: true),
                            NovdocFilterChip(label: 'Yarı zamanlı'),
                            NovdocFilterChip(label: 'Nöbet usulü'),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: NovdocPrimaryButton(
                label: '14 ilanı göster',
                height: 52,
                onPressed: () => context.pop(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _section(
    String title,
    IconData icon, {
    required List<String> chips,
    required int selected,
  }) {
    return NovdocCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(title, style: AppTypography.heading(fontSize: 16)),
              Icon(icon, color: AppColors.accent),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (var i = 0; i < chips.length; i++)
                NovdocFilterChip(label: chips[i], selected: i == selected),
            ],
          ),
        ],
      ),
    );
  }
}
