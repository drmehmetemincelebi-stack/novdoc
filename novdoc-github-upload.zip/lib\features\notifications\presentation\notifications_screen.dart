import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/novdoc_icon_button.dart';
import '../../../core/widgets/novdoc_ui.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.screenHorizontal,
            24,
            AppSpacing.screenHorizontal,
            32,
          ),
          children: [
            Row(
              children: [
                NovdocIconButton(
                  icon: LucideIcons.arrow_left,
                  onPressed: () => context.pop(),
                  semanticLabel: 'Geri dön',
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('NOVDOC', style: AppTypography.labelAccent()),
                      Text('Bildirimler', style: AppTypography.heading(fontSize: 24)),
                    ],
                  ),
                ),
                NovdocIconButton(
                  icon: LucideIcons.settings_2,
                  onPressed: () => context.push('/settings'),
                  semanticLabel: 'Bildirim ayarları',
                ),
              ],
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.secondary,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                children: [
                  const Icon(LucideIcons.bell_ring, color: AppColors.accent),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      '4 okunmamış bildirim',
                      style: AppTypography.body(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: AppColors.secondaryForeground,
                      ),
                    ),
                  ),
                  Text(
                    'Tümünü oku',
                    style: AppTypography.body(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: AppColors.primary,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Text('Bugün', style: AppTypography.heading(fontSize: 16)),
            const SizedBox(height: 12),
            for (final n in _items) ...[
              _NotificationTile(item: n),
              const SizedBox(height: 12),
            ],
          ],
        ),
      ),
    );
  }
}

class _NotificationTile extends StatelessWidget {
  const _NotificationTile({required this.item});

  final _Notif item;

  @override
  Widget build(BuildContext context) {
    return NovdocCard(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: AppColors.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.border),
            ),
            child: Icon(item.icon, color: AppColors.primary),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        item.title,
                        style: AppTypography.heading(fontSize: 15),
                      ),
                    ),
                    Text(
                      item.time,
                      style: AppTypography.body(
                        fontSize: 11,
                        color: AppColors.mutedForeground,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  item.body,
                  style: AppTypography.body(
                    fontSize: 14,
                    color: AppColors.mutedForeground,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Notif {
  const _Notif(this.title, this.body, this.time, this.icon);
  final String title;
  final String body;
  final String time;
  final IconData icon;
}

const _items = [
  _Notif(
    'Başvurunuz inceleniyor',
    'Acıbadem Maslak Hastanesi başvurunuzu değerlendirmeye aldı.',
    '09:42',
    LucideIcons.clipboard_check,
  ),
  _Notif(
    'Size uygun yeni ilan',
    'Profilinizle eşleşen 3 yeni Nöroloji ilanı yayınlandı.',
    '08:15',
    LucideIcons.sparkles,
  ),
];
