import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/constants/app_assets.dart';
import '../../../core/providers/app_session_provider.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/job_listing_card.dart';
import '../../../shared/repositories/jobs_repository.dart';
import '../../../core/widgets/novdoc_states.dart';

class DoctorFavoritesScreen extends ConsumerWidget {
  const DoctorFavoritesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final empty = ref.watch(appSessionProvider.select((s) => s.favoritesEmpty));
    final jobsAsync = ref.watch(recommendedJobsProvider);

    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: empty
            ? NovdocEmptyState(
                imageUrl: AppAssets.emptyFavorites,
                title: 'Henüz favori ilanınız yok',
                description:
                    'Beğendiğiniz ilanları kaydedin; fırsatları tek ekranda takip edin.',
                primaryLabel: 'İlanları keşfet',
                primaryAction: () {
                  ref.read(appSessionProvider.notifier).toggleFavoritesEmpty();
                  context.go('/doctor/home');
                },
              )
            : jobsAsync.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (_, __) => Center(
                  child: TextButton(
                    onPressed: () => ref.invalidate(recommendedJobsProvider),
                    child: const Text('Tekrar dene'),
                  ),
                ),
                data: (jobs) => ListView(
                  padding: const EdgeInsets.fromLTRB(
                    AppSpacing.screenHorizontal,
                    24,
                    AppSpacing.screenHorizontal,
                    120,
                  ),
                  children: [
                    Text(
                      'Favori İlanlarım (${jobs.length})',
                      style: AppTypography.heading(fontSize: 24),
                    ),
                    const SizedBox(height: 20),
                    for (final job in jobs)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 16),
                        child: RepaintBoundary(
                          child: JobListingCard(job: job),
                        ),
                      ),
                  ],
                ),
              ),
      ),
    );
  }
}
