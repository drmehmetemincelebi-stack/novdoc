import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../../core/constants/app_assets.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/novdoc_button.dart';
import '../../../core/widgets/novdoc_icon_button.dart';
import '../../../core/widgets/novdoc_network_image.dart';
import '../../../core/widgets/novdoc_states.dart';
import '../../../core/widgets/novdoc_ui.dart';
import '../../../shared/models/job_listing.dart';
import '../../../shared/repositories/jobs_repository.dart';

class JobDetailScreen extends ConsumerWidget {
  const JobDetailScreen({super.key, required this.jobId});

  final String jobId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final jobAsync = ref.watch(jobDetailProvider(jobId));

    return Scaffold(
      body: jobAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, __) => NovdocErrorState(
          imageUrl: AppAssets.errorIllustration,
          onRetry: () => ref.invalidate(jobDetailProvider(jobId)),
          onHome: () => context.go('/doctor/home'),
        ),
        data: (job) {
          if (job == null) {
            return const Center(child: Text('İlan bulunamadı'));
          }
          return _JobDetailBody(job: job);
        },
      ),
    );
  }
}

class _JobDetailBody extends StatelessWidget {
  const _JobDetailBody({required this.job});

  final JobListing job;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Stack(
                  children: [
                    SizedBox(
                      height: 142,
                      width: double.infinity,
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          NovdocNetworkImage(
                            url: AppAssets.jobHero,
                            fit: BoxFit.cover,
                            height: 142,
                          ),
                          Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  AppColors.primary.withValues(alpha: 0.55),
                                  AppColors.primary.withValues(alpha: 0.1),
                                  AppColors.background,
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      left: 20,
                      top: 48,
                      child: NovdocIconButton(
                        icon: LucideIcons.arrow_left,
                        onPressed: () => context.pop(),
                        semanticLabel: 'Geri dön',
                      ),
                    ),
                    Positioned(
                      right: 20,
                      top: 48,
                      child: NovdocIconButton(
                        icon: LucideIcons.heart,
                        onPressed: () {},
                        semanticLabel: 'Favorilere ekle',
                      ),
                    ),
                  ],
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(
                  AppSpacing.screenHorizontal,
                  0,
                  AppSpacing.screenHorizontal,
                  120,
                ),
                sliver: SliverList(
                  delegate: SliverChildListDelegate([
                    Transform.translate(
                      offset: const Offset(0, -40),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Container(
                            width: 76,
                            height: 76,
                            decoration: BoxDecoration(
                              color: AppColors.card,
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: AppColors.border),
                            ),
                            alignment: Alignment.center,
                            child: Container(
                              width: 56,
                              height: 56,
                              decoration: BoxDecoration(
                                color: job.logoColor,
                                borderRadius: BorderRadius.circular(16),
                              ),
                              alignment: Alignment.center,
                              child: Text(
                                job.logoLetter,
                                style: AppTypography.heading(
                                  color: Colors.white,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          ),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: AppColors.success,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              'Doğrulandı',
                              style: AppTypography.body(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: AppColors.successForeground,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Text('Uzman Hekim İlanı • Yeni'.toUpperCase(),
                        style: AppTypography.labelAccent()),
                    const SizedBox(height: 8),
                    Text(
                      job.title,
                      style: AppTypography.heading(
                        fontSize: 27,
                        color: AppColors.primary,
                      ),
                    ),
                    Text(
                      job.hospitalName,
                      style: AppTypography.body(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 16),
                    _infoGrid(job),
                    const SizedBox(height: 20),
                    Text(
                      job.description,
                      style: AppTypography.body(
                        fontSize: 15,
                        color: AppColors.mutedForeground,
                        height: 1.5,
                      ),
                    ),
                  ]),
                ),
              ),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
          decoration: const BoxDecoration(
            border: Border(top: BorderSide(color: AppColors.border)),
            color: AppColors.background,
          ),
          child: Row(
            children: [
              Expanded(
                child: NovdocPrimaryButton(
                  label: 'Başvur',
                  height: 52,
                  onPressed: () {},
                ),
              ),
              const SizedBox(width: 12),
              NovdocSecondaryButton(
                label: 'Paylaş',
                expanded: false,
                height: 52,
                onPressed: () {},
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _infoGrid(JobListing job) {
    final items = [
      (LucideIcons.map_pin, 'Lokasyon', job.city),
      (LucideIcons.briefcase, 'Çalışma şekli', job.workType),
      (LucideIcons.clock_3, 'Çalışma saatleri', '08:30 – 17:30'),
      (LucideIcons.calendar_days, 'Yayınlanma', job.publishedAgo),
    ];
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      childAspectRatio: 2.2,
      children: [
        for (final (icon, label, value) in items)
          NovdocCard(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Icon(icon, color: AppColors.accent, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        label,
                        style: AppTypography.body(
                          fontSize: 11,
                          color: AppColors.mutedForeground,
                        ),
                      ),
                      Text(
                        value,
                        style: AppTypography.body(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
}
