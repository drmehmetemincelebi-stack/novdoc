import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../core/constants/app_assets.dart';
import '../../../core/widgets/novdoc_states.dart';

class ErrorScreen extends StatelessWidget {
  const ErrorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: NovdocErrorState(
          imageUrl: AppAssets.errorIllustration,
          onRetry: () => context.go('/loading'),
          onHome: () => context.go('/doctor/home'),
        ),
      ),
    );
  }
}
