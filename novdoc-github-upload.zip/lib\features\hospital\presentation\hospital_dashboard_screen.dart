import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/novdoc_button.dart';
import '../../../core/widgets/novdoc_icon_button.dart';
import '../../../core/widgets/novdoc_ui.dart';
import '../../../shared/mock/mock_data.dart';

class HospitalDashboardScreen extends StatelessWidget {
  const HospitalDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.screenHorizontal,
            28,
            AppSpacing.screenHorizontal,
            120,
          ),
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Hastane yönetimi', style: AppTypography.labelAccent()),
                      const SizedBox(height: 8),
                      Text(
                        MockData.hospitalName,
                        style: AppTypography.heading(fontSize: 24),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          const Icon(LucideIcons.badge_check,
                              size: 16, color: AppColors.success),
                          const SizedBox(width: 6),
                          Text(
                            'Doğrulanmış kurum',
                            style: AppTypography.body(
                              fontSize: 14,
                              color: AppColors.mutedForeground,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                NovdocIconButton(
                  icon: LucideIcons.bell,
                  onPressed: () => context.push('/notifications'),
                  semanticLabel: 'Bildirimler',
                ),
              ],
            ),
            const SizedBox(height: 24),
            NovdocPrimaryButton(
              label: 'Yeni İlan Oluştur',
              icon: LucideIcons.plus,
              height: 52,
              onPressed: () => context.push('/hospital/listings/new'),
            ),
            const SizedBox(height: 28),
            Text('Genel görünüm', style: AppTypography.heading(fontSize: 16)),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _stat('8', 'Aktif İlan', LucideIcons.briefcase)),
                const SizedBox(width: 10),
                Expanded(child: _stat('126', 'Toplam Başvuru', LucideIcons.files)),
                const SizedBox(width: 10),
                Expanded(child: _stat('14', 'Yeni Başvuru', LucideIcons.sparkles)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _stat(String value, String label, IconData icon) {
    return NovdocCard(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: AppColors.primary, size: 20),
          const SizedBox(height: 16),
          Text(value, style: AppTypography.heading(fontSize: 24)),
          const SizedBox(height: 4),
          Text(
            label,
            style: AppTypography.body(
              fontSize: 12,
              color: AppColors.mutedForeground,
            ),
          ),
        ],
      ),
    );
  }
}
