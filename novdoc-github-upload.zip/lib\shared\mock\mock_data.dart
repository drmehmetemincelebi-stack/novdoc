import 'package:flutter/material.dart';

import 'job_listing.dart';

abstract final class MockData {
  static const doctorName = 'Dr. Elif';
  static const doctorFullName = 'Dr. Elif Yılmaz';
  static const hospitalName = 'Acıbadem Maslak';

  static final sampleJobs = [
    JobListing(
      id: '1',
      title: 'Kardiyoloji Uzmanı',
      hospitalName: 'Acıbadem Maslak Hastanesi',
      city: 'İstanbul',
      workType: 'Tam zamanlı',
      description:
          'İleri kardiyak görüntüleme deneyimi olan, hasta odaklı yaklaşımı benimseyen uzman hekim arıyoruz.',
      publishedAgo: '2 saat önce yayınlandı',
      logoLetter: 'A',
      logoColor: Color(0xFFD7213A),
      badges: const [
        JobBadge('Yeni', JobBadgeVariant.accent),
        JobBadge('Doğrulandı', JobBadgeVariant.success),
        JobBadge('Lojman', JobBadgeVariant.secondary),
      ],
      footerLeft: '2 saat önce yayınlandı',
      footerRight: 'Maaş bilgisi mevcut',
      footerRightIsSuccess: true,
      salaryAvailable: true,
    ),
    JobListing(
      id: '2',
      title: 'Acil Tıp Uzmanı',
      hospitalName: 'Memorial Ankara Hastanesi',
      city: 'Ankara',
      workType: 'Vardiyalı',
      description:
          'Modern acil servis ekibimize katılacak, ekip çalışmasına uyumlu ve iletişimi güçlü uzman hekim.',
      publishedAgo: 'Dün yayınlandı',
      logoLetter: 'M',
      logoColor: Color(0xFFE72635),
      badges: const [
        JobBadge('Yeni', JobBadgeVariant.accent),
        JobBadge('Acil', JobBadgeVariant.destructive),
        JobBadge('Maaş Bilgisi', JobBadgeVariant.secondary),
      ],
      footerLeft: 'Dün yayınlandı',
      footerRight: '12 başvuru',
    ),
  ];
}
