import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/novdoc_button.dart';
import '../../../core/widgets/novdoc_icon_button.dart';
import '../../../core/widgets/novdoc_ui.dart';

class HospitalNewListingScreen extends StatefulWidget {
  const HospitalNewListingScreen({super.key});

  @override
  State<HospitalNewListingScreen> createState() => _HospitalNewListingScreenState();
}

class _HospitalNewListingScreenState extends State<HospitalNewListingScreen> {
  int _step = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.screenHorizontal,
            24,
            AppSpacing.screenHorizontal,
            24,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  NovdocIconButton(
                    icon: LucideIcons.arrow_left,
                    onPressed: () => context.pop(),
                    semanticLabel: 'Geri dön',
                  ),
                  Text(
                    'Taslak otomatik kaydedilir',
                    style: AppTypography.body(
                      fontSize: 11,
                      color: AppColors.mutedForeground,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              Text('Yeni ilan oluştur', style: AppTypography.labelAccent()),
              Text(
                'Pozisyonu tanımlayalım',
                style: AppTypography.heading(fontSize: 27, height: 1.15),
              ),
              const SizedBox(height: 16),
              LinearProgressIndicator(
                value: (_step + 1) / 3,
                minHeight: 6,
                backgroundColor: AppColors.muted,
                color: AppColors.primary,
                borderRadius: BorderRadius.circular(8),
              ),
              const SizedBox(height: 24),
              Expanded(
                child: SingleChildScrollView(
                  child: NovdocCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        if (_step == 0) ...[
                          _select('Branş', 'Kardiyoloji'),
                          const SizedBox(height: 12),
                          _select('Departman', 'Poliklinik'),
                          const SizedBox(height: 12),
                          _select('Çalışma şehri', 'İstanbul'),
                        ] else if (_step == 1) ...[
                          const TextField(
                            maxLines: 4,
                            decoration: InputDecoration(
                              labelText: 'İlan açıklaması',
                            ),
                          ),
                        ] else ...[
                          Text(
                            'Önizleme hazır — yayınlamadan önce bilgileri kontrol edin.',
                            style: AppTypography.body(color: AppColors.mutedForeground),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
              NovdocPrimaryButton(
                label: _step < 2 ? 'Sonraki adım' : 'İlanı yayınla',
                height: 52,
                onPressed: () {
                  if (_step < 2) {
                    setState(() => _step++);
                  } else {
                    context.go('/hospital/listings');
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _select(String label, String value) {
    return InputDecorator(
      decoration: InputDecoration(labelText: label),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          isExpanded: true,
          items: [value]
              .map((v) => DropdownMenuItem(value: v, child: Text(v)))
              .toList(),
          onChanged: (_) {},
        ),
      ),
    );
  }
}
