import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../../core/providers/app_session_provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/novdoc_button.dart';
import '../../../core/widgets/novdoc_states.dart';
import '../../../core/widgets/novdoc_ui.dart';

class DoctorApplicationsScreen extends ConsumerWidget {
  const DoctorApplicationsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final empty = ref.watch(appSessionProvider.select((s) => s.applicationsEmpty));

    if (empty) {
      return Scaffold(
        body: SafeArea(
          child: NovdocEmptyState(
            title: 'Henüz başvurunuz yok',
            description:
                'İlgilendiğiniz ilanlara başvurun; sürecinizi buradan takip edin.',
            primaryLabel: 'İlanları incele',
            primaryAction: () {
              ref.read(appSessionProvider.notifier).toggleApplicationsEmpty();
              context.go('/doctor/home');
            },
          ),
        ),
      );
    }

    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.screenHorizontal,
            24,
            AppSpacing.screenHorizontal,
            120,
          ),
          children: [
            Text('Başvurularım (6)', style: AppTypography.heading(fontSize: 24)),
            const SizedBox(height: 8),
            Text(
              'Başvuru durumlarınızı anlık takip edin.',
              style: AppTypography.body(color: AppColors.mutedForeground),
            ),
            const SizedBox(height: 20),
            for (final item in _items)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: NovdocCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              item.title,
                              style: AppTypography.heading(fontSize: 16),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: AppColors.secondary,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              item.status,
                              style: AppTypography.body(
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                color: AppColors.secondaryForeground,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        item.hospital,
                        style: AppTypography.body(
                          fontSize: 14,
                          color: AppColors.mutedForeground,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          const Icon(LucideIcons.clock_3,
                              size: 14, color: AppColors.accent),
                          const SizedBox(width: 6),
                          Text(
                            item.date,
                            style: AppTypography.body(
                              fontSize: 12,
                              color: AppColors.mutedForeground,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      NovdocSecondaryButton(
                        label: 'Detayları gör',
                        outlined: true,
                        height: 40,
                        onPressed: () => context.push('/doctor/job/1'),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  static const _items = [
    _AppItem('Kardiyoloji Uzmanı', 'Acıbadem Maslak', 'İnceleniyor', '2 gün önce'),
    _AppItem('Acil Tıp Uzmanı', 'Memorial Ankara', 'Yeni', 'Dün'),
  ];
}

class _AppItem {
  const _AppItem(this.title, this.hospital, this.status, this.date);
  final String title;
  final String hospital;
  final String status;
  final String date;
}
