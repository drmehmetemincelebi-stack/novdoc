import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../../core/widgets/novdoc_icon_button.dart';
import '../../../core/widgets/novdoc_states.dart';

class LoadingScreen extends StatelessWidget {
  const LoadingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(20),
              child: NovdocIconButton(
                icon: LucideIcons.arrow_left,
                onPressed: () => context.pop(),
                semanticLabel: 'Geri dön',
              ),
            ),
            const Expanded(child: NovdocLoadingSkeleton()),
          ],
        ),
      ),
    );
  }
}
