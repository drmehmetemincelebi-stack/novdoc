import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../../core/constants/app_assets.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/novdoc_button.dart';
import '../../../core/widgets/novdoc_icon_button.dart';
import '../../../core/widgets/novdoc_ui.dart';

class DoctorProfileEditScreen extends StatelessWidget {
  const DoctorProfileEditScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.screenHorizontal,
                20,
                AppSpacing.screenHorizontal,
                16,
              ),
              child: Row(
                children: [
                  NovdocIconButton(
                    icon: LucideIcons.arrow_left,
                    onPressed: () => context.pop(),
                    semanticLabel: 'Profile geri dön',
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Profesyonel profil', style: AppTypography.labelAccent()),
                        Text('Profil Düzenle', style: AppTypography.heading(fontSize: 20)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(
                  AppSpacing.screenHorizontal,
                  0,
                  AppSpacing.screenHorizontal,
                  24,
                ),
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColors.secondary,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(
                      'Profiliniz %82 tamamlandı',
                      style: AppTypography.heading(
                        fontSize: 18,
                        color: AppColors.secondaryForeground,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  NovdocCard(
                    child: Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: CachedNetworkImage(
                            imageUrl: AppAssets.doctorProfileEdit,
                            width: 96,
                            height: 96,
                            fit: BoxFit.cover,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Profesyonel bir fotoğraf kullanın',
                                style: AppTypography.body(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 8),
                              NovdocSecondaryButton(
                                label: 'Fotoğraf yükle',
                                expanded: false,
                                height: 36,
                                icon: LucideIcons.upload,
                                onPressed: () {},
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  NovdocCard(
                    child: Column(
                      children: [
                        _field('Ad soyad', 'Dr. Elif Yılmaz'),
                        const SizedBox(height: 12),
                        _field('Uzmanlık', 'Kardiyoloji'),
                        const SizedBox(height: 12),
                        _field('Şehir', 'İstanbul'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: NovdocPrimaryButton(
                label: 'Değişiklikleri kaydet',
                height: 52,
                onPressed: () => context.pop(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: AppTypography.body(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: AppColors.mutedForeground,
          ),
        ),
        const SizedBox(height: 6),
        TextField(controller: TextEditingController(text: value)),
      ],
    );
  }
}
