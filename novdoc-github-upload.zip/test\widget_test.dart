import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:novdoc/app.dart';

void main() {
  setUpAll(() {
    GoogleFonts.config.allowRuntimeFetching = false;
  });

  testWidgets('NOVDOC splash renders brand', (tester) async {
    await tester.pumpWidget(const ProviderScope(child: NovdocApp()));
    await tester.pump();
    expect(find.textContaining('NOVDOC'), findsWidgets);
  });
}
