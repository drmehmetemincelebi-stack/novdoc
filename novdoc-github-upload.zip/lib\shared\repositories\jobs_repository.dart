import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/job_listing.dart';
import '../mock/mock_data.dart';

/// Veri kaynağı arayüzü — ileride Supabase/REST ile değiştirilir.
abstract interface class JobsDataSource {
  Future<List<JobListing>> fetchRecommended();
  Future<JobListing?> fetchById(String id);
}

class MockJobsDataSource implements JobsDataSource {
  @override
  Future<List<JobListing>> fetchRecommended() async {
    await Future<void>.delayed(const Duration(milliseconds: 350));
    return MockData.sampleJobs;
  }

  @override
  Future<JobListing?> fetchById(String id) async {
    await Future<void>.delayed(const Duration(milliseconds: 150));
    for (final job in MockData.sampleJobs) {
      if (job.id == id) return job;
    }
    return MockData.sampleJobs.isEmpty ? null : MockData.sampleJobs.first;
  }
}

class JobsRepository {
  JobsRepository(this._source);

  final JobsDataSource _source;
  List<JobListing>? _cache;

  Future<List<JobListing>> getRecommended({bool forceRefresh = false}) async {
    if (!forceRefresh && _cache != null) return _cache!;
    final data = await _source.fetchRecommended();
    _cache = data;
    return data;
  }

  Future<JobListing?> getById(String id) => _source.fetchById(id);

  void invalidate() => _cache = null;
}

final jobsDataSourceProvider = Provider<JobsDataSource>(
  (ref) => MockJobsDataSource(),
);

final jobsRepositoryProvider = Provider<JobsRepository>(
  (ref) => JobsRepository(ref.watch(jobsDataSourceProvider)),
);

final recommendedJobsProvider = FutureProvider<List<JobListing>>((ref) async {
  return ref.watch(jobsRepositoryProvider).getRecommended();
});

final jobDetailProvider =
    FutureProvider.family<JobListing?, String>((ref, id) async {
  return ref.watch(jobsRepositoryProvider).getById(id);
});
