import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../../core/constants/app_assets.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_radius.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/novdoc_button.dart';
import '../../../core/widgets/novdoc_icon_button.dart';
import '../../../core/widgets/novdoc_ui.dart';
import '../../../shared/mock/mock_data.dart';

class DoctorProfileScreen extends StatelessWidget {
  const DoctorProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.screenHorizontal,
            28,
            AppSpacing.screenHorizontal,
            120,
          ),
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Profesyonel profil', style: AppTypography.labelAccent()),
                    const SizedBox(height: 4),
                    Text('Profilim', style: AppTypography.heading(fontSize: 24)),
                  ],
                ),
                NovdocIconButton(
                  icon: LucideIcons.settings_2,
                  semanticLabel: 'Profil ayarları',
                  onPressed: () => context.push('/settings'),
                ),
              ],
            ),
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.secondary,
                borderRadius: BorderRadius.circular(AppRadius.theme),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(28),
                        child: CachedNetworkImage(
                          imageUrl: AppAssets.doctorProfile,
                          width: 112,
                          height: 112,
                          fit: BoxFit.cover,
                        ),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.card,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          children: [
                            const Icon(LucideIcons.badge_check,
                                size: 16, color: AppColors.accent),
                            const SizedBox(width: 6),
                            Text(
                              'Doğrulanmış',
                              style: AppTypography.body(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: AppColors.primary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Text(
                    MockData.doctorFullName,
                    style: AppTypography.heading(fontSize: 25),
                  ),
                  Text(
                    'Kardiyoloji Uzmanı',
                    style: AppTypography.heading(
                      fontSize: 16,
                      color: AppColors.primary,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'Hasta odaklı yaklaşımı ve koruyucu kardiyoloji alanındaki deneyimiyle modern sağlık ekiplerine değer katmayı hedefleyen hekim.',
                    style: AppTypography.body(
                      fontSize: 14,
                      height: 1.5,
                      color: AppColors.foreground.withValues(alpha: 0.8),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            NovdocPrimaryButton(
              label: 'Profili Düzenle',
              icon: LucideIcons.square_pen,
              onPressed: () => context.push('/doctor/profile/edit'),
            ),
            const SizedBox(height: 20),
            NovdocCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Profil gücü', style: AppTypography.labelAccent()),
                  const SizedBox(height: 8),
                  Text('%82 tamamlandı', style: AppTypography.heading(fontSize: 18)),
                  const SizedBox(height: 12),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: const LinearProgressIndicator(
                      value: 0.82,
                      minHeight: 8,
                      backgroundColor: AppColors.muted,
                      color: AppColors.accent,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
